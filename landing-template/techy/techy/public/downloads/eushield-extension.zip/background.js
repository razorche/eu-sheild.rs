const DEFAULT_STATS = { date: todayKey(), count: 0 };
const DEFAULT_POLICY = {
  names: true,
  ibans: true,
  emails: true,
  amounts: true,
  phones: true,
  customRegex: true,
  customPattern: "",
};

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

async function ensureDefaults() {
  const data = await chrome.storage.local.get(["leakStats", "shieldEnabled", "scrubPolicy"]);
  let stats = data.leakStats || DEFAULT_STATS;
  if (stats.date !== todayKey()) {
    stats = { date: todayKey(), count: 0 };
    await chrome.storage.local.set({ leakStats: stats });
  }
  if (data.shieldEnabled === undefined) {
    await chrome.storage.local.set({ shieldEnabled: true });
  }
  if (!data.scrubPolicy) {
    await chrome.storage.local.set({ scrubPolicy: DEFAULT_POLICY });
  }
  return stats;
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaults();
});

async function broadcastToChatTabs(message) {
  const tabs = await chrome.tabs.query({
    url: [
      "https://chat.openai.com/*",
      "https://chatgpt.com/*",
      "https://claude.ai/*",
    ],
  });
  for (const tab of tabs) {
    if (tab.id) chrome.tabs.sendMessage(tab.id, message).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === "GET_STATE") {
      const data = await chrome.storage.local.get([
        "shieldEnabled",
        "leakStats",
        "scrubPolicy",
      ]);
      const session = await chrome.storage.session.get(["tokenVault"]);
      let stats = data.leakStats || DEFAULT_STATS;
      if (stats.date !== todayKey()) {
        stats = { date: todayKey(), count: 0 };
        await chrome.storage.local.set({ leakStats: stats });
      }
      const vault = session.tokenVault || {};
      sendResponse({
        shieldEnabled: data.shieldEnabled !== false,
        leaksBlockedToday: stats.count,
        policy: data.scrubPolicy || DEFAULT_POLICY,
        vaultSize: Object.keys(vault).length,
      });
      return;
    }
    if (msg.type === "SET_SHIELD") {
      await chrome.storage.local.set({ shieldEnabled: Boolean(msg.enabled) });
      await broadcastToChatTabs({
        type: "SHIELD_STATE_CHANGED",
        enabled: Boolean(msg.enabled),
      });
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === "SET_POLICY") {
      const current = (await chrome.storage.local.get("scrubPolicy")).scrubPolicy || DEFAULT_POLICY;
      const next = { ...current, ...(msg.policy || {}) };
      await chrome.storage.local.set({ scrubPolicy: next });
      await broadcastToChatTabs({ type: "POLICY_CHANGED", policy: next });
      sendResponse({ ok: true, policy: next });
      return;
    }
    if (msg.type === "PURGE_VAULT") {
      await chrome.storage.session.remove("tokenVault");
      await broadcastToChatTabs({ type: "PURGE_VAULT" });
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === "TEST_TOKENIZE") {
      sendResponse({ ok: true, note: "Run test in popup via tokenizer bundle" });
      return;
    }
    if (msg.type === "REDACTION_OK") {
      const stats = await ensureDefaults();
      stats.count += 1;
      await chrome.storage.local.set({ leakStats: stats });
      sendResponse({ ok: true, count: stats.count });
    }
  })();
  return true;
});
