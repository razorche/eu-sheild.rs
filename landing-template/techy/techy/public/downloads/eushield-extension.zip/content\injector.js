(function EUShieldInjector() {
  const CHANNEL = "EUSHIELD_V1";
  const TARGET_HOSTS = ["chat.openai.com", "chatgpt.com", "claude.ai"];
  const DEV_WARN = true;

  let shieldEnabled = true;
  let policy = { ...EUShieldTokenizer.DEFAULT_POLICY };
  const sessionVault = new Map();

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.channel !== CHANNEL) return;
    if (event.data.type === "SHIELD_STATE") shieldEnabled = Boolean(event.data.enabled);
    if (event.data.type === "POLICY_STATE" && event.data.policy) {
      policy = EUShieldTokenizer.mergePolicy(event.data.policy);
    }
  });

  function post(type, payload) {
    window.postMessage({ channel: CHANNEL, type, ...payload }, "*");
  }

  function devWarn(...args) {
    if (DEV_WARN) console.warn("[EUShield]", ...args);
  }

  function abortShield(reason, detail) {
    post("FAIL_CLOSED", { reason, detail });
    const err = new Error(`EUShield fail-closed: ${reason}`);
    err.euShield = { reason, detail };
    return err;
  }

  function matchesHost(url) {
    try {
      const host = new URL(url, location.origin).hostname.replace(/^www\./, "");
      return TARGET_HOSTS.some((h) => host === h || host.endsWith(`.${h}`));
    } catch {
      return false;
    }
  }

  async function readBody(init, original) {
    if (init?.body instanceof FormData) return { kind: "form", raw: init.body };
    if (init?.body instanceof URLSearchParams) return { kind: "text", raw: init.body.toString() };
    if (typeof init?.body === "string") return { kind: "text", raw: init.body };
    if (init?.body instanceof ArrayBuffer || ArrayBuffer.isView(init?.body)) {
      return { kind: "binary", raw: init.body };
    }
    if (original?.clone) {
      const text = await original.clone().text();
      return { kind: "text", raw: text };
    }
    return { kind: "unknown", raw: null };
  }

  function tryParseJson(raw) {
    if (typeof raw !== "string") return null;
    const trimmed = raw.trim().replace(/^\uFEFF/, "");
    try {
      return JSON.parse(trimmed);
    } catch {
      /* fallthrough */
    }
    const firstLine = trimmed.split("\n").find((line) => line.trim());
    if (firstLine) {
      try {
        return JSON.parse(firstLine.trim());
      } catch {
        /* fallthrough */
      }
    }
    return null;
  }

  function notifyRedaction(categories) {
    const mapObj = Object.fromEntries(sessionVault);
    post("REDACTION_OK", { categories: categories || [], map: mapObj });
    post("SYNC_VAULT", { map: mapObj });
  }

  /**
   * When JSON.parse fails: regex/tokenize the raw string.
   * - No PII detected -> fail-open (return { passthrough: true })
   * - PII redacted -> return { body: string }
   * - PII detected but redaction fails -> throw
   */
  function attemptRawStringFallback(raw) {
    devWarn(
      "JSON parse failed; attempting raw-string tokenizer fallback.",
      raw.length > 240 ? `${raw.slice(0, 240)}...` : raw
    );

    const probeVault = new Map();
    let probe;
    try {
      probe = EUShieldTokenizer.tokenizeText(raw, probeVault, policy);
    } catch (err) {
      throw abortShield("TOKENIZE", err?.message || "Raw fallback tokenization failed");
    }

    if (!probe.hadPii) {
      devWarn("Raw fallback: no PII patterns detected — fail-open (forwarding unchanged).");
      return { passthrough: true };
    }

    try {
      const result = EUShieldTokenizer.tokenizeText(raw, sessionVault, policy);
      if (!result.hadPii || result.text === raw) {
        throw abortShield(
          "TOKENIZE",
          "PII was detected but raw-string redaction produced no safe output"
        );
      }
      notifyRedaction([...result.categories]);
      return { body: result.text, passthrough: false };
    } catch (err) {
      if (String(err).includes("fail-closed")) throw err;
      throw abortShield("TOKENIZE", err?.message || "Raw fallback redaction failed");
    }
  }

  function processParsedJson(json) {
    const result = EUShieldTokenizer.redactJsonObject(json, sessionVault, policy);
    if (result.hasAttachment) throw abortShield("ATTACHMENT", "File or image part detected");
    if (result.touched) notifyRedaction(result.categories);
    return result.touched ? JSON.stringify(result.body) : JSON.stringify(json);
  }

  function processRawText(raw) {
    const json = tryParseJson(raw);
    if (json) {
      try {
        return processParsedJson(json);
      } catch (err) {
        if (String(err).includes("fail-closed")) throw err;
        throw abortShield("TOKENIZE", err?.message || "Tokenization error");
      }
    }

    const fallback = attemptRawStringFallback(raw);
    if (fallback.passthrough) return null;
    return fallback.body;
  }

  async function processOutbound(url, init, originalRequest) {
    if (!shieldEnabled) return null;
    if (!matchesHost(url)) return null;

    const bodyInfo = await readBody(init, originalRequest);
    if (bodyInfo.kind === "form" || bodyInfo.kind === "binary") {
      throw abortShield("ATTACHMENT", "Multimodal payload blocked in v1");
    }
    if (bodyInfo.kind === "unknown" || bodyInfo.raw == null) {
      throw abortShield("PARSE", "Unknown request body shape");
    }

    return processRawText(bodyInfo.raw);
  }

  const nativeFetch = window.fetch.bind(window);
  window.fetch = async function patchedFetch(input, init) {
    const req = input instanceof Request ? input : new Request(input, init);
    const url = req.url;
    if (!shieldEnabled || !matchesHost(url)) return nativeFetch(input, init);
    try {
      const mergedInit = {
        method: req.method,
        headers: req.headers,
        body: init?.body ?? (req.method !== "GET" && req.method !== "HEAD" ? req.body : undefined),
        credentials: init?.credentials ?? req.credentials,
        mode: init?.mode ?? req.mode,
        cache: init?.cache ?? req.cache,
        redirect: init?.redirect ?? req.redirect,
        referrer: init?.referrer ?? req.referrer,
        integrity: init?.integrity ?? req.integrity,
      };
      const newBody = await processOutbound(url, mergedInit, req);
      if (newBody != null) {
        mergedInit.body = newBody;
        if (mergedInit.headers?.set) mergedInit.headers.set("content-type", "application/json");
      }
      return nativeFetch(new Request(url, mergedInit));
    } catch (e) {
      return Promise.reject(e);
    }
  };

  const xhrOpen = XMLHttpRequest.prototype.open;
  const xhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function open(method, url, ...rest) {
    this.__euUrl = url;
    return xhrOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function send(body) {
    if (shieldEnabled && matchesHost(this.__euUrl || "")) {
      try {
        if (body instanceof FormData) throw abortShield("ATTACHMENT");
        if (typeof body === "string") {
          const next = processRawText(body);
          if (next != null) return xhrSend.call(this, next);
          return xhrSend.call(this, body);
        }
      } catch (err) {
        throw err;
      }
    }
    return xhrSend.call(this, body);
  };

  post("INJECTOR_READY", { version: 3 });
})();
