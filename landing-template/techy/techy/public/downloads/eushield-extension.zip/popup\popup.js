const toggle = document.getElementById("shield-toggle");
const panel = document.getElementById("shield-panel");
const label = document.getElementById("shield-label");
const hint = document.getElementById("shield-hint");
const counterEl = document.getElementById("flip-counter");
const categoryRoot = document.getElementById("category-toggles");
const customPattern = document.getElementById("custom-pattern");
const vaultSizeEl = document.getElementById("vault-size");
const testInput = document.getElementById("test-input");
const testOutput = document.getElementById("test-output");

let policy = { ...EUShieldTokenizer.DEFAULT_POLICY };

function pad4(n) {
  return String(Math.max(0, Math.min(9999, n))).padStart(4, "0");
}

function renderCounter(value) {
  const s = pad4(value);
  const digits = counterEl.querySelectorAll(".eu-digit span");
  [...digits].forEach((span, i) => {
    if (span.textContent !== s[i]) span.textContent = s[i];
  });
}

function applyShieldUI(enabled) {
  toggle.checked = enabled;
  panel.classList.toggle("is-off", !enabled);
  label.textContent = enabled ? "SHIELD ACTIVE" : "UNPROTECTED";
  hint.textContent = enabled
    ? "Fail-closed protection enabled"
    : "Outbound prompts are not redacted";
}

function applyCategoryUI() {
  categoryRoot.querySelectorAll(".eu-pill").forEach((pill) => {
    const key = pill.dataset.key;
    const on = policy[key] !== false;
    pill.classList.toggle("eu-pill-active", on);
  });
  customPattern.value = policy.customPattern || "";
}

function refreshState() {
  chrome.runtime.sendMessage({ type: "GET_STATE" }, (res) => {
    if (chrome.runtime.lastError || !res) return;
    applyShieldUI(res.shieldEnabled);
    renderCounter(res.leaksBlockedToday || 0);
    policy = { ...EUShieldTokenizer.DEFAULT_POLICY, ...(res.policy || {}) };
    applyCategoryUI();
    vaultSizeEl.textContent = String(res.vaultSize || 0);
  });
}

toggle.addEventListener("change", () => {
  chrome.runtime.sendMessage({ type: "SET_SHIELD", enabled: toggle.checked }, refreshState);
});

categoryRoot.addEventListener("click", (e) => {
  const pill = e.target.closest(".eu-pill");
  if (!pill) return;
  const key = pill.dataset.key;
  const next = { ...policy, [key]: policy[key] === false };
  chrome.runtime.sendMessage({ type: "SET_POLICY", policy: next }, refreshState);
});

document.getElementById("save-regex").addEventListener("click", () => {
  const next = {
    ...policy,
    customPattern: customPattern.value.trim(),
    customRegex: true,
  };
  chrome.runtime.sendMessage({ type: "SET_POLICY", policy: next }, refreshState);
});

document.getElementById("purge-vault").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "PURGE_VAULT" }, refreshState);
});

document.getElementById("run-test").addEventListener("click", () => {
  const { redacted, map } = EUShieldTokenizer.tokenizeDisplay(testInput.value, policy);
  testOutput.textContent = `${redacted}\n\n--- map ---\n${JSON.stringify(map, null, 2)}`;
});

refreshState();
setInterval(refreshState, 3000);
