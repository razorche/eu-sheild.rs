(function EUShieldBridge() {
  const CHANNEL = "EUSHIELD_V1";

  function injectMainScripts() {
    const files = ["lib/tokenizer.js", "lib/dom-shield.js", "content/injector.js"];
    for (const file of files) {
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(file);
      script.async = false;
      (document.documentElement || document.head).appendChild(script);
      script.remove();
    }
  }

  injectMainScripts();

  const modalCss = document.createElement("link");
  modalCss.rel = "stylesheet";
  modalCss.href = chrome.runtime.getURL("styles/modal.css");
  document.documentElement.appendChild(modalCss);

  let modalRoot = null;

  function ensureModal() {
    if (modalRoot) return modalRoot;
    modalRoot = document.createElement("div");
    modalRoot.id = "eushield-modal-host";
    modalRoot.setAttribute("aria-live", "assertive");
    document.documentElement.appendChild(modalRoot);
    return modalRoot;
  }

  const FAIL_COPY = {
    PARSE:
      "EUShield blocked this send because ChatGPT/Claude changed their protocol. Security first - an update is on the way.",
    TOKENIZE:
      "EUShield blocked this send because sensitive data could not be tokenized safely. No data left your machine.",
    ATTACHMENT:
      "EUShield currently protects text-only prompts. Remove files/images to continue safely.",
    PROTOCOL:
      "EUShield blocked this send due to an unrecognized AI transport. Your compliance team has been kept safe.",
  };

  function showFailModal(reason, detail) {
    const host = ensureModal();
    const version = chrome.runtime.getManifest().version;
    host.innerHTML = `
      <div class="eu-modal-backdrop" role="dialog" aria-modal="true">
        <div class="eu-modal-card">
          <div class="eu-modal-glow"></div>
          <div class="eu-modal-icon" aria-hidden="true"></div>
          <p class="eu-modal-eyebrow">FAIL-CLOSED PROTECTION</p>
          <h2 class="eu-modal-title">Send blocked</h2>
          <p class="eu-modal-body">${FAIL_COPY[reason] || FAIL_COPY.PROTOCOL}</p>
          ${detail ? `<p class="eu-modal-detail">${detail}</p>` : ""}
          <p class="eu-modal-meta">EUShield v${version} | ${reason}</p>
          <button type="button" class="eu-modal-btn" id="eushield-modal-dismiss">Understood</button>
        </div>
      </div>`;
    host.querySelector("#eushield-modal-dismiss")?.addEventListener("click", () => {
      host.innerHTML = "";
    });
  }

  function postToPage(type, payload) {
    window.postMessage({ channel: CHANNEL, type, ...payload }, "*");
  }

  function syncFromStorage() {
    chrome.storage.local.get(["shieldEnabled", "scrubPolicy"], (data) => {
      postToPage("SHIELD_STATE", { enabled: data.shieldEnabled !== false });
      postToPage("POLICY_STATE", { policy: data.scrubPolicy });
    });
    chrome.storage.session.get(["tokenVault"], (data) => {
      if (data.tokenVault) postToPage("SYNC_VAULT", { map: data.tokenVault });
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "SHIELD_STATE_CHANGED") {
      postToPage("SHIELD_STATE", { enabled: msg.enabled });
    }
    if (msg.type === "POLICY_CHANGED") {
      postToPage("POLICY_STATE", { policy: msg.policy });
    }
    if (msg.type === "PURGE_VAULT") {
      postToPage("PURGE_VAULT", {});
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") {
      if (changes.shieldEnabled) {
        postToPage("SHIELD_STATE", { enabled: changes.shieldEnabled.newValue !== false });
      }
      if (changes.scrubPolicy) {
        postToPage("POLICY_STATE", { policy: changes.scrubPolicy.newValue });
      }
    }
    if (area === "session" && changes.tokenVault) {
      postToPage("SYNC_VAULT", { map: changes.tokenVault.newValue || {} });
    }
  });

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.channel !== CHANNEL) return;
    const { type, reason, detail, categories, map } = event.data;

    if (type === "FAIL_CLOSED") {
      showFailModal(reason || "PROTOCOL", detail);
      return;
    }

    if (type === "REDACTION_OK") {
      chrome.runtime.sendMessage({ type: "REDACTION_OK", categories: categories || [] });
      if (map) chrome.storage.session.set({ tokenVault: map });
    }

    if (type === "SYNC_VAULT" && map) {
      chrome.storage.session.set({ tokenVault: map });
    }

    if (type === "INJECTOR_READY") syncFromStorage();
  });

  syncFromStorage();
})();
